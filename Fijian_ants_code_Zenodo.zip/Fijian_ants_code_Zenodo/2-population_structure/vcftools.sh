#!/bin/bash

# Filter SNPs using vcftools
# Original parameters described in the manuscript
# maf depends on sample size to remove the singleton SNPs
vcftools \
  --vcf input.vcf \
  --minQ 30 \
  --minDP 10 \
  --maxDP 45 \
  --max-missing 0.7 \
  --maf 0.05 \
  --remove-indv low_cov_individuals.txt \
  --recode \
  --recode-INFO-all \
  --out filtered_snps