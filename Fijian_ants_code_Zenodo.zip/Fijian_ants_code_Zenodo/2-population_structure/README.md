# 2-Population Structure Analyses

This folder contains scripts used for SNP filtering, VCF conversion, PCA, t-SNE, and Fst calculation based on RADseq data.

## Contents

- `vcftools.sh` – VCFtools command for SNP filtering: Phred ≥30, DP 10–45, MAC ≥2, site coverage ≥70%
- `ipyrad_vcf2single_snp.py` – Python 2 script used in the paper to retain one SNP per RAD locus
- `convert_vcf_to_hdf5.py` – Converts filtered VCFs to HDF5 format
- `pca.py` – Runs PCA and t-SNE using HDF5 files and outputs 2D plots and PC axes
- `fst.py` – Script used in the published paper to calculate Weir & Cockerham FST values