#!/usr/bin/env python3
"""
PCA analysis using ipyrad.analysis.pca on HDF5 file

Full documentation can be found: https://ipyrad.readthedocs.io/en/master/API-analysis/cookbook-pca.html
"""

import ipyrad.analysis as ipa
import pandas as pd
import os
import toyplot
import toyplot.pdf


# Input data and popmap
sp_name = " "
data = "FILEPATH"+sp_name+".snps.hdf5"

imap = {}
popmap = pd.read_table("./FILEPATH"+sp_name+"_popmap.txt", sep="\t")

# Build the imap for PCA
for i in popmap['pop'].unique().tolist():
    popmap_slice = popmap[popmap['pop'] == i]
    imap[i] = popmap_slice['indv'].tolist()

# Require that 10% of samples have data in each group
minmap = {i: 0.1 for i in imap}

# Initialize PCA
pca = ipa.pca(
    data=data,
    imap=imap,
    minmap=minmap,
    mincov=0.75,
    impute_method=3, #impute_method="Sample"
)

# Run PCA analysis
pca.run()

# Store the PC axes as a dataframe
df = pd.DataFrame(pca.pcaxes[0], index=pca.names)

# Write the PC axes to a CSV file
df.to_csv(f"{sp_name}_pca_analysis.csv")

# Plot PCA results and display them in Jupyter Notebook
canvas, axes = pca.draw(ax0=0, ax1=1)
toyplot.pdf.render(canvas, f"{sp_name}-PCA.pdf")
canvas