# Load required libraries
library(ape)
library(ggtree)
library(ggplot2)
library(dplyr)
library(tidyr)
library(ggridges)
library(patchwork)
library(dunn.test)

# Read the sorted tree
tree <- read.tree("./Data/fijian_beast_tree2.tre")
tree <- ladderize(tree, right = FALSE)

# Read the original dataset
data <- read.csv("./Data/fijian_tree_species_ecology.csv", stringsAsFactors = FALSE)

# Read the new dataset (fst_d values)
fst_data <- read.csv("./Data/population_fst_data.csv", stringsAsFactors = FALSE)

# Ensure `tree_id` format matches tree tip labels in both datasets
tree$tip.label <- gsub("'", "", tree$tip.label)
data$tree_id <- gsub("_", ".", data$tree_id)  
fst_data$tree_id <- gsub("_", ".", fst_data$tree_id)  
tree$tip.label <- gsub("_", ".", tree$tip.label)  

# Merge the new dataset with the original dataset based on `tree_id`
data <- merge(data, fst_data, by = "tree_id", all.x = T)  # Ensure all original species are retained

data$endemic_class <- as.factor(data$endemic_class.x)

tree_data <- data %>%
  select(tree_id, endemic_class.x, Disturbance, Elevation, fst_d) %>%
  pivot_longer(cols = c(Disturbance, Elevation, fst_d), names_to = "Variable", values_to = "Value")

tree_data$tree_id <- factor(tree_data$tree_id, levels = rev(tree$tip.label))

print(table(tree_data$Variable))

endemic_colors <- c("widespread pacific native" = "blue",
                    "endemic" = "green",
                    "Exotic" = "yellow")  

max_time <- max(node.depth.edgelength(tree))

# Plotting
p_tree <- ggtree(tree, size = 0.7) + 
  geom_tiplab(align = TRUE, size = 3, hjust = -0.1) +
  theme_tree2() +
  ggtitle("Phylogenetic Tree with Time Scale") +
  scale_x_continuous(name = "Time (millions of years ago)", limits = c(0, max_time))  


p_disturbance <- ggplot(tree_data %>% filter(Variable == "Disturbance"),
                        aes(x = Value, y = tree_id, fill = endemic_class.x)) +
  geom_density_ridges(alpha = 0.7, scale = 1) +  
  scale_fill_manual(values = endemic_colors, guide = "none") +
  scale_x_continuous(limits = c(0, 4)) +  
  theme_minimal() +
  labs(x = "Disturbance", y = "") +
  theme(axis.text.y = element_blank(), axis.ticks.y = element_blank()) +
  ggtitle("Disturbance Density")


p_elevation <- ggplot(tree_data %>% filter(Variable == "Elevation"),
                      aes(x = Value, y = tree_id, fill = endemic_class.x)) +
  geom_density_ridges(alpha = 0.7, scale = 1) +  
  scale_fill_manual(values = endemic_colors, guide = "none") +  
  scale_x_continuous(limits = c(0, 1500)) +  
  theme_minimal() +
  labs(x = "Elevation", y = "") +
  theme(axis.text.y = element_blank(), axis.ticks.y = element_blank()) +  
  ggtitle("Elevation Density")


p_fst_d <- ggplot(tree_data %>% filter(Variable == "fst_d"),
                  aes(x = Value, y = tree_id, fill = endemic_class.x)) +
  geom_density_ridges(alpha = 0.7, scale = 1) +  
  scale_fill_manual(values = endemic_colors, guide = "none") +  
  theme_minimal() +xlim(0,0.005)+
  labs(x = "Fst_d", y = "") +
  theme(axis.text.y = element_blank(), axis.ticks.y = element_blank()) +  
  ggtitle("Fst_d Density")


final_plot <- p_tree | p_disturbance | p_elevation | p_fst_d  

print(final_plot)


pdf(file="figure1_with_fst_d.pdf", width=25, height=15)  # Increased width for 4 columns
print(final_plot)
dev.off()


#### plotting the boxplots for figure 1
library(ggplot2)
library(dplyr)


data <- read.csv("./data/fijian_tree_species_ecology.csv", stringsAsFactors = FALSE)

data_fst<-read.csv("./data/population_fst_data.csv")

data$endemic_class <- factor(data$endemic_class, levels = rev(c("endemic", "widespread pacific native", "Exotic")))
data_fst$endemic_class<- factor(data_fst$endemic_class, levels = rev(c("endemic", "widespread pacific native", "Exotic")))

endemic_colors <- c("endemic" = "green",
                    "widespread pacific native" = "blue",
                    "Exotic" = "yellow")


p_disturbance_boxplot <- ggplot(data, aes(x = Disturbance, y = endemic_class, fill = endemic_class)) +
  geom_boxplot(alpha = 0.7) +
  scale_fill_manual(values = endemic_colors, guide = "none") +
  theme_minimal()+ 
  labs(x = "Disturbance", y = "Endemic Class") +
  ggtitle("Disturbance Boxplot")


p_elevation_boxplot <- ggplot(data, aes(x = Elevation, y = endemic_class, fill = endemic_class)) +
  geom_boxplot(alpha = 0.7) +
  scale_fill_manual(values = endemic_colors, guide = "none") +
  theme_minimal() +
  labs(x = "Elevation", y = "Endemic Class") +
  ggtitle("Elevation Boxplot")


p_fst_boxplot <- ggplot(data_fst, aes(x = fst_d, y = endemic_class, fill = endemic_class)) +
  geom_boxplot(alpha = 0.7) +
  scale_fill_manual(values = endemic_colors, guide = "none") +
  theme_minimal() +xlim(0,0.005)+
  labs(x = "FST", y = "Endemic Class") +
  ggtitle("FST Boxplot")



print(p_disturbance_boxplot)
print(p_elevation_boxplot)
print(p_fst_boxplot)


pdf(file="corrected_boxplots_fst.pdf", width=5, height=5)
#print(p_disturbance_boxplot)
#print(p_elevation_boxplot)
print(p_fst_boxplot)
dev.off()







