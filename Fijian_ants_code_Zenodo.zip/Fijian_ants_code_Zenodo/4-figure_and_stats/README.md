# 4-Figure Generation and Statistical Analyses

This folder contains R/Python scripts and supporting data used to generate the main figures and perform statistical analyses for the study.

## Contents

- `data/` – Data folder used for plotting and model fitting
- `figure1.r` – R script to generate Figure 1
- `figure2.r` – R script to generate Figure 2
- `Figure1_statistics.r` – Statistical tests and summaries associated with Figure 1
- `Main_statistics.r` – Main Bayesian model used in the study; also includes code to generate Figure 3
