#!/bin/bash

source activate python3
ipyrad -p ipyrad_params_phylogeny.txt -s1234567 -f -b -d -c 40