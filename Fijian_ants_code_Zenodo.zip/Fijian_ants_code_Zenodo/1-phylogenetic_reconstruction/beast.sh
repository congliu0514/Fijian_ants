#!/bin/bash

beast -threads 24 beast_fijian.xml