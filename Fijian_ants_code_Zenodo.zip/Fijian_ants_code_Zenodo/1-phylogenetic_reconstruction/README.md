# 1-Phylogenetic reconstruction for Fijian Ants

This folder contains scripts and parameter files used to assemble RADseq loci, and construct phylogenies using ipyrad, ExaML, and BEAST.

## Contents

- `ipyrad_assembly.sh` – Shell script to run ipyrad assembly (v.0.9.43)
- `ipyrad_params.txt` – Parameter file used for ipyrad run
- `examl.sh` – Shell script to run ExaML on ipyrad output alignment (*.phy)
- `beast.sh` – Command to run BEAST

## Tree Files
- `Fijian_ants_examl.tre`: Maximum likelihood phylogeny of Fijian ants inferred with ExaML based on 1,481,890 RADseq loci. Node numbers reflect bootstrap support. Scale in substitution per unit branch length.
- `Fijian_ants_beast.tre`: Time-calibrated phylogeny of Fijian ants. The tree is based on the maximum-likelihood topology estimated with ExaML and was time-calibrated in BEAST2.

