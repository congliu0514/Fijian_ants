#!/bin/bash
# Run fastsimcoal2 100 times

# Define directories
input_folder="path1"      # Path to the folder containing .obs, .tpl, and .est files
output_folder="path2"     # Path to save all output files
num_runs=100              # Number of times to run fastsimcoal28 for each population

# List of population names
populations=("A" "B")


# Run fsc28 for population
run_fsc() {
  population=$1
  population_input_folder="${input_folder}"
  population_output_folder="${output_folder}/${population}"

  mkdir -p "${population_output_folder}"

  for run in $(seq 1 $num_runs); do
    run_folder="${population_output_folder}/run_${run}"
    mkdir -p "${run_folder}"

    # Run fsc28 (make sure .obs in the same folder as .tpl and .est)
    ./fsc28 -t "${population_input_folder}/${population}.tpl" \
                  -e "${population_input_folder}/${population}.est" \
                  -n 1000000 -M -L 40 -m -x -q -c 10 > "${run_folder}/fsc_run.log" 2>&1

    echo "Run ${run} for population ${population} completed"
  done
}

# Main loop to run fastsimcoal28 for all populations
for population in "${populations[@]}"; do
  tpl_file="${input_folder}/${population}.tpl"
  est_file="${input_folder}/${population}.est"
  
  if [ -f "${tpl_file}" ] && [ -f "${est_file}" ]; then
    echo "Processing population ${population}..."
    run_fsc "${population}"
  else
    echo "Missing input files for population ${population}, skipping..."
  fi
done