#!/bin/bash
# This script runs easySFS.py to generate site frequency spectra (SFS) for demographic modeling.
# It previews projection values for each VCF file and ask for the number.
# (i.e., the one that maximizes the number of segregating sites).
#
# Input:
#   - VCF file (*.vcf) and population map (*.txt) in each subdirectory
#   - Population map file should be in easySFS format (sample names and population labels)
# Requires: `easySFS.py` (https://github.com/isaacovercast/easySFS)



for f in {FILEPATH}
do
echo $f
cd $f
../easySFS.py -i *.vcf -p *.txt -a --preview
echo "choose the projection values that maximizing the number of segregating sites:"
read number
../easySFS.py -i *.vcf -p *.txt --proj $number -f
cd ..
done